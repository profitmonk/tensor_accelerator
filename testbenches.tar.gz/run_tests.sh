#!/bin/bash
# Tensor Accelerator Test Suite

cd "$(dirname "$0")"
PASS=0; FAIL=0

echo ""
echo "╔════════════════════════════════════════════════════════════╗"
echo "║        Tensor Accelerator - Test Suite                     ║"
echo "╚════════════════════════════════════════════════════════════╝"

mkdir -p sim

# Test 1: MAC PE
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "TEST 1: MAC PE"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
iverilog -o sim/tb_mac rtl/core/mac_pe.v tb/tb_mac_pe.v
(cd sim && vvp tb_mac) > /tmp/test1.log 2>&1
tail -10 /tmp/test1.log
if grep -q "ALL TESTS PASSED" /tmp/test1.log; then
    echo "✓ PASSED"; ((PASS++))
else
    echo "✗ FAILED"; ((FAIL++))
fi

# Test 2: Systolic Array
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "TEST 2: Systolic Array"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
iverilog -o sim/tb_sys rtl/core/mac_pe.v rtl/core/systolic_array.v tb/tb_systolic_array.v
(cd sim && vvp tb_sys) > /tmp/test2.log 2>&1
tail -10 /tmp/test2.log
if grep -q "ALL TESTS PASSED" /tmp/test2.log; then
    echo "✓ PASSED"; ((PASS++))
else
    echo "✗ FAILED"; ((FAIL++))
fi

# Test 3: LCP
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "TEST 3: Local Command Processor"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
iverilog -g2012 -o sim/tb_lcp rtl/control/local_cmd_processor.v tb/tb_local_cmd_processor.v
(cd sim && vvp tb_lcp) > /tmp/test3.log 2>&1
tail -10 /tmp/test3.log
if grep -q "ALL TESTS PASSED" /tmp/test3.log; then
    echo "✓ PASSED"; ((PASS++))
else
    echo "✗ FAILED"; ((FAIL++))
fi

# Summary
echo ""
echo "╔════════════════════════════════════════════════════════════╗"
echo "║                    TEST SUMMARY                            ║"
echo "╠════════════════════════════════════════════════════════════╣"
printf "║   Passed: %-3d                                             ║\n" $PASS
printf "║   Failed: %-3d                                             ║\n" $FAIL
echo "╚════════════════════════════════════════════════════════════╝"

if [ $FAIL -eq 0 ]; then
    echo ">>> ALL TESTS PASSED! <<<"
else
    echo ">>> SOME TESTS FAILED <<<"
fi
