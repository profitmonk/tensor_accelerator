# Waveform Screenshots

Place your waveform screenshots here:

- mac_pe_waveform.png
- systolic_array_waveform.png
- systolic_load.png
- systolic_compute.png

See docs/WAVEFORMS.md for capture instructions.
