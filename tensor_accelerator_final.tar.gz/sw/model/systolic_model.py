#!/usr/bin/env python3
"""
Cycle-Accurate Systolic Array Functional Model

This model implements a weight-stationary systolic array with:
- Input activation skewing (row i delayed by i cycles)
- Vertical partial sum accumulation
- Output de-skewing (column j delayed by appropriate cycles)

The model tracks ALL internal signals cycle-by-cycle for comparison with RTL.
"""

import numpy as np
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Tuple
import json


@dataclass
class MACPEState:
    """State of a single MAC Processing Element"""
    row: int
    col: int
    
    # Registers
    weight_reg: int = 0
    act_reg: int = 0      # Registered activation (1 cycle delay)
    
    # Outputs (directly from registers, updated each cycle)
    act_out: int = 0      # Passed to right neighbor
    psum_out: int = 0     # Passed to bottom neighbor
    
    # For debugging
    product: int = 0      # Current multiplication result
    
    def load_weight(self, weight: int):
        """Load weight into stationary register"""
        self.weight_reg = weight
    
    def compute(self, act_in: int, psum_in: int, enable: bool, clear_acc: bool) -> Tuple[int, int]:
        """
        Compute one cycle of MAC operation.
        
        Returns: (act_out, psum_out) for this cycle
        """
        if not enable:
            return self.act_out, self.psum_out
        
        # Compute product using REGISTERED activation (from previous cycle)
        self.product = self.act_reg * self.weight_reg
        
        # Update psum_out
        if clear_acc:
            self.psum_out = self.product
        else:
            self.psum_out = psum_in + self.product
        
        # Pass activation to right (with 1 cycle delay via act_reg)
        self.act_out = self.act_reg
        
        # Register the NEW activation input for next cycle
        self.act_reg = act_in
        
        return self.act_out, self.psum_out
    
    def reset(self):
        """Reset all registers"""
        self.act_reg = 0
        self.act_out = 0
        self.psum_out = 0
        self.product = 0
        # Note: weight_reg is NOT reset (stationary)
    
    def __repr__(self):
        return f"PE[{self.row},{self.col}](w={self.weight_reg}, act_reg={self.act_reg}, psum_out={self.psum_out})"


@dataclass 
class SkewRegister:
    """
    Input skewing shift register for one row.
    Row i needs i stages of delay.
    """
    row: int
    num_stages: int  # Equal to row index
    stages: List[int] = field(default_factory=list)
    output: int = 0
    
    def __post_init__(self):
        self.stages = [0] * self.num_stages if self.num_stages > 0 else []
    
    def shift(self, input_val: int, enable: bool) -> int:
        """
        Shift new value in, return output value.
        For row 0 (no delay), output = input directly.
        """
        if not enable:
            return self.output
            
        if self.num_stages == 0:
            # Row 0: no delay, direct passthrough
            self.output = input_val
        else:
            # Shift register: output from last stage
            self.output = self.stages[-1] if self.stages else input_val
            
            # Shift all stages
            for i in range(self.num_stages - 1, 0, -1):
                self.stages[i] = self.stages[i-1]
            if self.num_stages > 0:
                self.stages[0] = input_val
        
        return self.output
    
    def reset(self):
        self.stages = [0] * self.num_stages
        self.output = 0


@dataclass
class DeskewRegister:
    """
    Output de-skewing shift register for one column.
    Column j needs 2*(ARRAY_SIZE-1-j) stages of delay.
    """
    col: int
    num_stages: int
    stages: List[int] = field(default_factory=list)
    output: int = 0
    
    def __post_init__(self):
        self.stages = [0] * self.num_stages if self.num_stages > 0 else []
    
    def shift(self, input_val: int, enable: bool) -> int:
        """Shift new value in, return output value."""
        if not enable:
            return self.output
            
        if self.num_stages == 0:
            self.output = input_val
        else:
            self.output = self.stages[-1] if self.stages else input_val
            for i in range(self.num_stages - 1, 0, -1):
                self.stages[i] = self.stages[i-1]
            if self.num_stages > 0:
                self.stages[0] = input_val
        
        return self.output
    
    def reset(self):
        self.stages = [0] * self.num_stages
        self.output = 0


class SystolicArrayModel:
    """
    Cycle-accurate model of weight-stationary systolic array.
    
    Dataflow:
    - Weights loaded into PEs (stationary)
    - Activations stream left-to-right with input skewing
    - Partial sums flow top-to-bottom
    - Results emerge from bottom with output de-skewing
    """
    
    def __init__(self, array_size: int = 4, data_width: int = 8, acc_width: int = 32):
        self.array_size = array_size
        self.data_width = data_width
        self.acc_width = acc_width
        
        # Create PE array
        self.pes: List[List[MACPEState]] = [
            [MACPEState(row=r, col=c) for c in range(array_size)]
            for r in range(array_size)
        ]
        
        # Input skewing registers (one per row)
        # Row i has i stages of delay
        self.input_skew: List[SkewRegister] = [
            SkewRegister(row=r, num_stages=r) for r in range(array_size)
        ]
        
        # Output de-skewing registers (one per column)
        # Column j has 2*(array_size-1-j) stages of delay
        self.output_deskew: List[DeskewRegister] = [
            DeskewRegister(col=c, num_stages=2*(array_size-1-c)) for c in range(array_size)
        ]
        
        # State machine
        self.state = 'IDLE'  # IDLE, LOAD, COMPUTE, DRAIN, DONE
        self.cycle_count = 0
        self.cfg_k_tiles = 0
        
        # Signals
        self.busy = False
        self.done = False
        self.result_valid = False
        self.act_ready = False
        
        # Inter-PE wiring (updated each cycle)
        # act_h[row][col] = activation entering PE[row][col] from left
        self.act_h: List[List[int]] = [[0]*(array_size+1) for _ in range(array_size)]
        # psum_v[row][col] = partial sum entering PE[row][col] from top
        self.psum_v: List[List[int]] = [[0]*(array_size) for _ in range(array_size+1)]
        
        # Output
        self.result_data: List[int] = [0] * array_size
        
        # Trace log for debugging
        self.trace: List[Dict] = []
        self.trace_enabled = True
    
    def reset(self):
        """Reset all state"""
        for row in self.pes:
            for pe in row:
                pe.reset()
        for skew in self.input_skew:
            skew.reset()
        for deskew in self.output_deskew:
            deskew.reset()
        
        self.state = 'IDLE'
        self.cycle_count = 0
        self.busy = False
        self.done = False
        self.result_valid = False
        self.act_ready = False
        
        for r in range(self.array_size):
            for c in range(self.array_size + 1):
                self.act_h[r][c] = 0
        for r in range(self.array_size + 1):
            for c in range(self.array_size):
                self.psum_v[r][c] = 0
        
        self.result_data = [0] * self.array_size
        self.trace = []
    
    def load_weights(self, weights: np.ndarray):
        """
        Load weight matrix B into PE array.
        B[k][n] goes to PE[k][n].
        weights shape: (K, N) where K, N <= array_size
        """
        K, N = weights.shape
        for k in range(min(K, self.array_size)):
            for n in range(min(N, self.array_size)):
                self.pes[k][n].load_weight(int(weights[k, n]))
    
    def start(self, k_tiles: int, clear_acc: bool = True):
        """Start computation"""
        self.cfg_k_tiles = k_tiles
        self.state = 'COMPUTE'
        self.cycle_count = 0
        self.busy = True
        self.done = False
        self.act_ready = True
        
        if clear_acc:
            for row in self.pes:
                for pe in row:
                    pe.psum_out = 0
    
    def cycle(self, act_valid: bool = False, act_data: Optional[List[int]] = None, 
              clear_acc: bool = False) -> Dict:
        """
        Execute one clock cycle.
        
        Args:
            act_valid: True if activation data is valid
            act_data: List of activations, one per row [act[0], act[1], ...]
            clear_acc: Clear accumulators this cycle
        
        Returns:
            Dictionary with all signals for this cycle
        """
        if act_data is None:
            act_data = [0] * self.array_size
        
        # Determine enables based on state
        pe_enable = self.state in ('COMPUTE', 'DRAIN')
        skew_enable = self.state in ('COMPUTE', 'DRAIN')
        
        # ===== Input Skewing =====
        # Process skew registers to get activation inputs to column 0
        for row in range(self.array_size):
            input_val = act_data[row] if act_valid else 0
            skewed_val = self.input_skew[row].shift(input_val, skew_enable)
            self.act_h[row][0] = skewed_val
        
        # ===== PE Array Computation =====
        # Top row gets psum_in = 0
        for col in range(self.array_size):
            self.psum_v[0][col] = 0
        
        # Process PEs row by row, column by column
        for row in range(self.array_size):
            for col in range(self.array_size):
                pe = self.pes[row][col]
                
                # Get inputs
                act_in = self.act_h[row][col]
                psum_in = self.psum_v[row][col]
                
                # Compute
                act_out, psum_out = pe.compute(act_in, psum_in, pe_enable, 
                                                clear_acc and self.cycle_count == 0)
                
                # Route outputs
                self.act_h[row][col+1] = act_out
                self.psum_v[row+1][col] = psum_out
        
        # ===== Output De-skewing =====
        # Bottom row psum values go through de-skew registers
        for col in range(self.array_size):
            psum_bottom = self.psum_v[self.array_size][col]
            deskewed = self.output_deskew[col].shift(psum_bottom, pe_enable)
            self.result_data[col] = deskewed
        
        # ===== State Machine =====
        old_state = self.state
        
        if self.state == 'COMPUTE':
            # Check if we should transition to DRAIN
            # Need enough cycles for data to propagate: k_tiles + array_size - 1 + deskew
            total_cycles_needed = self.cfg_k_tiles + 3 * self.array_size - 3
            if self.cycle_count >= total_cycles_needed:
                self.state = 'DRAIN'
                self.cycle_count = 0
            else:
                self.cycle_count += 1
                
        elif self.state == 'DRAIN':
            if self.cycle_count >= self.array_size:
                self.state = 'DONE'
                self.done = True
                self.busy = False
            else:
                self.cycle_count += 1
                
        elif self.state == 'DONE':
            self.state = 'IDLE'
            self.done = False
        
        # Update result_valid
        # Results are valid after enough cycles for propagation + deskew
        if self.state == 'COMPUTE':
            propagation_delay = 3 * self.array_size - 3
            self.result_valid = self.cycle_count >= propagation_delay
        else:
            self.result_valid = self.state == 'DRAIN'
        
        self.act_ready = self.state == 'COMPUTE'
        
        # Create trace entry
        trace_entry = {
            'cycle': len(self.trace),
            'state': self.state,
            'cycle_count': self.cycle_count if self.state != old_state else self.cycle_count - 1,
            'act_valid': act_valid,
            'act_data': act_data.copy(),
            'result_valid': self.result_valid,
            'result_data': self.result_data.copy(),
            'act_h_col0': [self.act_h[r][0] for r in range(self.array_size)],
            'psum_bottom': [self.psum_v[self.array_size][c] for c in range(self.array_size)],
            'pe_states': [[{
                'weight': self.pes[r][c].weight_reg,
                'act_reg': self.pes[r][c].act_reg,
                'psum_out': self.pes[r][c].psum_out,
                'product': self.pes[r][c].product
            } for c in range(self.array_size)] for r in range(self.array_size)]
        }
        
        if self.trace_enabled:
            self.trace.append(trace_entry)
        
        return trace_entry
    
    def run_gemm(self, A: np.ndarray, B: np.ndarray, verbose: bool = True) -> np.ndarray:
        """
        Run complete GEMM: C = A × B
        
        Args:
            A: Activation matrix (M x K)
            B: Weight matrix (K x N)
            verbose: Print cycle-by-cycle trace
        
        Returns:
            Result matrix C (M x N)
        """
        M, K = A.shape
        K2, N = B.shape
        assert K == K2, f"Matrix dimension mismatch: A is {A.shape}, B is {B.shape}"
        assert M <= self.array_size and N <= self.array_size and K <= self.array_size
        
        self.reset()
        
        # Load weights
        self.load_weights(B)
        
        if verbose:
            print(f"\n{'='*60}")
            print(f"GEMM: A({M}x{K}) × B({K}x{N}) on {self.array_size}x{self.array_size} array")
            print(f"{'='*60}")
            print(f"A = \n{A}")
            print(f"B = \n{B}")
            print(f"Expected C = \n{A @ B}")
            print()
        
        # Start computation
        self.start(k_tiles=K)
        
        # Stream activations
        # At time m, send A[m][k] to row k for all k
        results = []
        cycle = 0
        
        # Send M rows of activations
        for m in range(M):
            act_data = [0] * self.array_size
            for k in range(K):
                act_data[k] = int(A[m, k])
            
            trace = self.cycle(act_valid=True, act_data=act_data)
            
            if verbose:
                self._print_cycle(cycle, trace)
            
            if trace['result_valid']:
                # Check if result is non-zero (actual data vs pipeline bubble)
                if any(v != 0 for v in trace['result_data'][:N]):
                    results.append(trace['result_data'][:N])
            
            cycle += 1
        
        # Continue cycling until done, collecting results
        max_cycles = 100
        while not self.done and cycle < max_cycles:
            trace = self.cycle(act_valid=False)
            
            if verbose:
                self._print_cycle(cycle, trace)
            
            if trace['result_valid'] and len(results) < M:
                if any(v != 0 for v in trace['result_data'][:N]) or len(results) > 0:
                    results.append(trace['result_data'][:N])
            
            cycle += 1
        
        # Convert results to matrix
        C = np.zeros((M, N), dtype=np.int32)
        for i, row in enumerate(results[:M]):
            for j, val in enumerate(row[:N]):
                C[i, j] = val
        
        if verbose:
            print(f"\nComputed C = \n{C}")
            expected = A @ B
            if np.array_equal(C, expected):
                print("✓ CORRECT!")
            else:
                print("✗ MISMATCH!")
                print(f"Expected:\n{expected}")
        
        return C
    
    def _print_cycle(self, cycle: int, trace: Dict):
        """Print one cycle of trace"""
        print(f"Cyc {cycle:2d} | state={trace['state']:7s} | "
              f"act_h[*][0]={trace['act_h_col0']} | "
              f"psum_bot={trace['psum_bottom']} | "
              f"result={trace['result_data']} | "
              f"rvalid={trace['result_valid']}")
    
    def get_pe_state(self, row: int, col: int) -> Dict:
        """Get current state of a specific PE"""
        pe = self.pes[row][col]
        return {
            'weight_reg': pe.weight_reg,
            'act_reg': pe.act_reg,
            'act_out': pe.act_out,
            'psum_out': pe.psum_out,
            'product': pe.product
        }
    
    def dump_trace(self, filename: str):
        """Dump trace to JSON file"""
        with open(filename, 'w') as f:
            json.dump(self.trace, f, indent=2)
    
    def generate_test_vectors(self, A: np.ndarray, B: np.ndarray, 
                               filename: str) -> None:
        """Generate test vectors for RTL verification"""
        self.trace_enabled = True
        self.run_gemm(A, B, verbose=False)
        
        with open(filename, 'w') as f:
            f.write("// Auto-generated test vectors\n")
            f.write(f"// A = {A.tolist()}\n")
            f.write(f"// B = {B.tolist()}\n")
            f.write(f"// Expected C = {(A @ B).tolist()}\n\n")
            
            for t in self.trace:
                f.write(f"// Cycle {t['cycle']}: state={t['state']}\n")
                f.write(f"// act_valid={t['act_valid']}, act_data={t['act_data']}\n")
                f.write(f"// result_valid={t['result_valid']}, result_data={t['result_data']}\n")
                f.write(f"// psum_bottom={t['psum_bottom']}\n\n")


def test_model():
    """Test the systolic array model"""
    print("="*60)
    print("Systolic Array Functional Model Test")
    print("="*60)
    
    # Test 1: Simple 2x2
    print("\n" + "="*60)
    print("TEST 1: 2x2 Matrix Multiply")
    print("="*60)
    
    model = SystolicArrayModel(array_size=4)
    
    A = np.array([[1, 1],
                  [2, 2]], dtype=np.int32)
    B = np.array([[1, 2],
                  [2, 3]], dtype=np.int32)
    
    C = model.run_gemm(A, B, verbose=True)
    expected = A @ B
    
    if np.array_equal(C, expected):
        print("\n>>> TEST 1 PASSED <<<")
    else:
        print("\n>>> TEST 1 FAILED <<<")
    
    # Test 2: 4x4 Identity
    print("\n" + "="*60)
    print("TEST 2: 4x4 Identity Matrix (C = A × I)")
    print("="*60)
    
    model = SystolicArrayModel(array_size=4)
    
    A = np.array([[1, 2, 3, 4],
                  [5, 6, 7, 8],
                  [9, 10, 11, 12],
                  [13, 14, 15, 16]], dtype=np.int32)
    B = np.eye(4, dtype=np.int32)
    
    C = model.run_gemm(A, B, verbose=True)
    expected = A @ B
    
    if np.array_equal(C, expected):
        print("\n>>> TEST 2 PASSED <<<")
    else:
        print("\n>>> TEST 2 FAILED <<<")
    
    # Test 3: General 3x3
    print("\n" + "="*60)
    print("TEST 3: General 3x3 Matrix Multiply")
    print("="*60)
    
    model = SystolicArrayModel(array_size=4)
    
    A = np.array([[1, 2, 3],
                  [4, 5, 6],
                  [7, 8, 9]], dtype=np.int32)
    B = np.array([[9, 8, 7],
                  [6, 5, 4],
                  [3, 2, 1]], dtype=np.int32)
    
    C = model.run_gemm(A, B, verbose=True)
    expected = A @ B
    
    if np.array_equal(C, expected):
        print("\n>>> TEST 3 PASSED <<<")
    else:
        print("\n>>> TEST 3 FAILED <<<")


if __name__ == "__main__":
    test_model()
