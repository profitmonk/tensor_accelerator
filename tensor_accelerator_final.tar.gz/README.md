# Tensor Accelerator - Complete Setup and Run Guide

## Quick Start

```bash
# 1. Install dependencies (Ubuntu/Debian)
sudo apt-get update
sudo apt-get install -y iverilog python3 python3-numpy

# 2. Run all 39 tests
./run_tests.sh

# Expected output: "Passed: 39, Failed: 0"
```

## Repository Structure

```
tensor_accelerator/
├── rtl/                        # Verilog RTL source
│   ├── core/
│   │   ├── mac_pe.v           # Multiply-accumulate PE
│   │   ├── systolic_array.v   # 8×8 systolic array
│   │   ├── vector_unit.v      # SIMD vector processor
│   │   └── dma_engine.v       # DMA controller
│   ├── control/
│   │   ├── local_cmd_processor.v   # Per-TPC command processor
│   │   └── global_cmd_processor.v  # Chip-level coordinator
│   ├── memory/
│   │   └── sram_subsystem.v   # 16-bank SRAM (2MB per TPC)
│   ├── noc/
│   │   └── noc_router.v       # 5-port XY router
│   └── top/
│       ├── tensor_processing_cluster.v  # Single TPC
│       └── tensor_accelerator_top.v     # 2×2 TPC grid
│
├── tb/                         # Testbenches (35 tests)
│   ├── tb_mac_pe.v
│   ├── tb_systolic_array.v
│   ├── tb_vector_unit.v
│   ├── tb_dma_engine.v
│   ├── tb_sram_subsystem.v
│   ├── tb_noc_router.v
│   ├── tb_tpc.v
│   ├── tb_top.v
│   ├── tb_e2e_*.v             # End-to-end tests
│   ├── tb_stress_test.v
│   ├── tb_lenet5.v
│   └── tb_resnet18_block.v
│
├── tests/realistic/            # Realistic model tests (4 tests)
│   ├── lenet/
│   │   ├── golden.py          # Python golden model
│   │   ├── tb_lenet_layer1_conv.v
│   │   ├── tb_lenet_layer3_pool.v
│   │   ├── tb_lenet_layer7_fc.v
│   │   └── test_vectors/      # Generated hex files
│   └── resnet_block/
│       ├── golden.py
│       ├── tb_resnet_block.v
│       └── test_vectors/
│
├── model/                      # Python models
│   ├── systolic_array_model.py
│   ├── vpu_model.py
│   ├── dma_model.py
│   ├── lcp_model.py
│   └── tpc_model.py
│
└── run_tests.sh               # Master test runner
```

## Running Tests

### Run All Tests (39 total)
```bash
./run_tests.sh
```

### Run Individual Tests

```bash
# Unit tests
iverilog -o sim/tb_mac rtl/core/mac_pe.v tb/tb_mac_pe.v && vvp sim/tb_mac
iverilog -o sim/tb_sys rtl/core/mac_pe.v rtl/core/systolic_array.v tb/tb_systolic_array.v && vvp sim/tb_sys
iverilog -g2012 -o sim/tb_vpu rtl/core/vector_unit.v tb/tb_vector_unit.v && vvp sim/tb_vpu

# Realistic model tests
python3 tests/realistic/lenet/golden.py  # Generate test vectors
iverilog -g2012 -o sim/tb_lenet1 tests/realistic/lenet/tb_lenet_layer1_conv.v && vvp sim/tb_lenet1

python3 tests/realistic/resnet_block/golden.py  # Generate test vectors
iverilog -g2012 -o sim/tb_resnet tests/realistic/resnet_block/tb_resnet_block.v && vvp sim/tb_resnet
```

## Test Categories

### Unit Tests (9 tests)
| Test | Description |
|------|-------------|
| MAC PE | Single multiply-accumulate cell |
| Systolic Array | 8×8 weight-stationary array |
| Vector Unit | SIMD operations (ADD, MUL, MAX, ReLU) |
| DMA Engine | Memory transfers |
| LCP | Local command processor |
| GCP | Global command processor |
| SRAM | 16-bank memory subsystem |
| NoC Router | 5-port XY routing |
| NoC Mesh | 2×2 router network |

### Integration Tests (2 tests)
| Test | Description |
|------|-------------|
| TPC | Full tensor processing cluster |
| Top | 2×2 TPC grid with NoC |

### End-to-End Tests (5 tests)
| Test | Description |
|------|-------------|
| Identity GEMM | Simple matrix multiply |
| Random 4×4 GEMM | Randomized small GEMM |
| Multi-GEMM | Sequential GEMMs |
| Conv2D | im2col convolution |
| Stress Test | Signed, overflow, sparse, fixed-point |

### Model Tests (10 tests)
| Test | Description |
|------|-------------|
| Random Matrix | Numpy-verified GEMM |
| Multi-TPC GEMM | Distributed computation |
| K-Accumulation | Large K-dimension tiling |
| VPU Element-wise | ADD, SUB, MUL, ReLU |
| VPU Reduce | SUM, MAX, MIN reductions |
| MaxPool 2×2 | CNN pooling layer |
| BatchNorm | Fused scale + bias |
| AvgPool | Average pooling |
| LeNet-5 | Full CNN model (toy size) |
| ResNet-18 Block | BN→ReLU→BN→Add→ReLU |

### Realistic Model Tests (4 tests)
| Test | Dimensions | Tiles | Cycles |
|------|-----------|-------|--------|
| LeNet Conv1 | (576,25)×(25,6) | 288 | 6,408 |
| LeNet Pool1 | 2×2 AvgPool | - | 864 |
| LeNet FC1 | (1,256)×(256,120) | 480 | 11,520 |
| ResNet Block | (3136,144)×(144,16)×2 | 28,224 | 677,376 |

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                    Tensor Accelerator                        │
│  ┌─────────────┐  ┌─────────────┐                           │
│  │   TPC[0,0]  │──│   TPC[0,1]  │                           │
│  │  ┌───────┐  │  │  ┌───────┐  │                           │
│  │  │8×8 SA │  │  │  │8×8 SA │  │  SA = Systolic Array      │
│  │  └───────┘  │  │  └───────┘  │  VPU = Vector Unit        │
│  │  ┌───────┐  │  │  ┌───────┐  │  SRAM = 2MB (16 banks)    │
│  │  │  VPU  │  │  │  │  VPU  │  │                           │
│  │  └───────┘  │  │  └───────┘  │                           │
│  │  ┌───────┐  │  │  ┌───────┐  │                           │
│  │  │ SRAM  │  │  │  │ SRAM  │  │                           │
│  │  └───────┘  │  │  └───────┘  │                           │
│  └──────┬──────┘  └──────┴──────┘                           │
│         │    NoC Mesh    │                                   │
│  ┌──────┴──────┐  ┌──────┴──────┐                           │
│  │   TPC[1,0]  │──│   TPC[1,1]  │                           │
│  └─────────────┘  └─────────────┘                           │
└─────────────────────────────────────────────────────────────┘
```

## Realistic Test Details

### LeNet-5 (28×28 MNIST)
```
Layer 1 (Conv1):
  Input:  28×28×1 → im2col → (576, 25)
  Weight: 6×1×5×5 → flatten → (25, 6)
  Output: (576, 6) → reshape → 24×24×6
  Tiles:  288 (M=72, K=4, N=1)

Layer 3 (Pool1):
  Input:  24×24×6
  Output: 12×12×6
  Op:     2×2 average pool (sum >> 2)

Layer 7 (FC1):
  Input:  256 (flattened 4×4×16)
  Weight: 120×256
  Output: 120
  Tiles:  480 (M=1, K=32, N=15)
```

### ResNet Block (56×56×16)
```
Input: (1, 16, 56, 56)
       │
       ├──────────────────────────────┐ (skip)
       ▼                              │
  Conv1: 3×3, 16→16, pad=1           │
  (3136, 144) × (144, 16)            │
  14,112 tiles                        │
       ▼                              │
  BN1 + ReLU                         │
       ▼                              │
  Conv2: 3×3, 16→16, pad=1           │
  14,112 tiles                        │
       ▼                              │
  BN2                                 │
       ▼                              │
  Add ←───────────────────────────────┘
       ▼
  ReLU
       ▼
Output: (1, 16, 56, 56)

Total: 28,224 tiles, ~677K cycles
```

## Generating Test Vectors

```bash
# LeNet vectors
cd tests/realistic/lenet
python3 golden.py
# Creates: test_vectors/layer1_im2col_int8.hex, layer1_weight_int8.hex, etc.

# ResNet vectors  
cd tests/realistic/resnet_block
python3 golden.py
# Creates: test_vectors/conv1_im2col_int8.hex, conv1_weight_int8.hex, etc.
```

## Dependencies

- **iverilog** (Icarus Verilog) - RTL simulation
- **Python 3** with NumPy - Golden models and test vector generation

```bash
# Ubuntu/Debian
sudo apt-get install iverilog python3 python3-numpy

# macOS
brew install icarus-verilog
pip3 install numpy

# Verify installation
iverilog -V
python3 -c "import numpy; print(numpy.__version__)"
```

## Expected Output

```
╔════════════════════════════════════════════════════════════╗
║        Tensor Accelerator - Full Test Suite                ║
╚════════════════════════════════════════════════════════════╝

═══════════════════ UNIT TESTS ═══════════════════
TEST: MAC PE
✓ PASSED
TEST: Systolic Array
✓ PASSED
...

═══════════════ REALISTIC MODEL TESTS ═══════════════
TEST: LeNet Layer1 Conv (28×28 realistic)
✓ PASSED
TEST: ResNet Block (56×56×16 realistic)
✓ PASSED

╔════════════════════════════════════════════════════════════╗
║                    TEST SUMMARY                            ║
╠════════════════════════════════════════════════════════════╣
║   Passed: 39                                              ║
║   Failed: 0                                               ║
╚════════════════════════════════════════════════════════════╝
>>> ALL TESTS PASSED! <<<
```
